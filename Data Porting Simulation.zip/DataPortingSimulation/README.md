# DataPortingSimulation
 
This is a simple application to demonstrate handling of data
between Frontend and Backend of an App. Database and(or) Room can be
utilised for more functionality. It is only a TEST PROJECT and its
source code SHOULD NOT BE USED for critical applications. In any case
@author is NOT RESPONSIBLE for bugs, crashes, or data loss that might
occour by re-purposing or re-using this project. Feel free to study/use
the source code whatsoever.

Apk dir: ~\\DataPortingSimulation\app\build\outputs\apk\debug\app-debug.apk
